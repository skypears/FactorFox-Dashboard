const Button = (props) => {
  return (
    <>
      <button className="theme-btn" type="button">{ props.children }</button>
    </>
)
};
export default Button;

